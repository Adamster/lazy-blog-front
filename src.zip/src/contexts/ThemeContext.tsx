"use client";

import { createContext, useContext, useEffect, useState } from "react";

const defaultTheme = {
  darkTheme: false,
  toggleTheme: () => {},
};

const ThemeContext = createContext(defaultTheme);

export const useTheme = () => {
  return useContext(ThemeContext);
};

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [darkTheme, setDarkTheme] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const localTheme = window.localStorage.getItem("darkTheme");
      setDarkTheme(localTheme === "true");
    }
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      document.body.className = darkTheme ? "dark" : "";

      if (darkTheme) {
        window.localStorage.setItem("darkTheme", "true");
      } else {
        window.localStorage.removeItem("darkTheme");
      }
    }
  }, [darkTheme]);

  const toggleTheme = () => setDarkTheme((prevTheme) => !prevTheme);

  return (
    <ThemeContext.Provider value={{ darkTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};
