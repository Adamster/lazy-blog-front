"use client";

import ErrorMessage from "@/components/errorMessages/ErrorMessage";
import Loading from "@/components/loading";
import { PostFull } from "@/components/post/PostFull";
import { IPost } from "@/types";
import { API_URL, fetcher } from "@/utils/fetcher";
import axios from "axios";
import { useSession } from "next-auth/react";
import Head from "next/head";
import { useEffect, useState } from "react";
import useSWR from "swr";
import { useParams } from "next/navigation";

function Post() {
  const { data: auth } = useSession();
  const params = useParams();
  const postId = params?.post;

  const { data, error, isLoading, mutate } = useSWR<IPost>(
    postId ? `${API_URL}/posts/${postId}` : "",
    fetcher
  );

  useEffect(() => {
    if (!data?.id || !auth?.user?.id) return;

    const postViewCounter = async () => {
      await axios.put(`${API_URL}/posts/${data?.id}/count-view`);
    };

    const timeout = setTimeout(() => {
      if (data?.id && data?.author?.id !== auth?.user.id) {
        postViewCounter();
      }
    }, 10000);

    return () => clearTimeout(timeout);
  }, [data?.id, auth?.user?.id]);

  if (error) return <ErrorMessage code={error.message} />;
  if (isLoading) return <Loading />;

  return (
    <>
      <Head>
        <title>{`${data?.title} | Not Lazy Blog`}</title>
        <meta key="og:title" property="og:title" content={data?.title} />
        <meta
          key="description"
          name="description"
          content={data?.summary || data?.body?.substring(0, 100)}
        />
        <meta
          key="og:description"
          property="og:description"
          content={data?.summary || data?.body?.substring(0, 100)}
        />
        <meta key="og:image" property="og:image" content={data?.coverUrl} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={data?.coverUrl} />
      </Head>

      {data?.id && <PostFull post={data} mutate={mutate} />}
    </>
  );
}

export default Post;
