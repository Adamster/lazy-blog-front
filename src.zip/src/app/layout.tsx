import type { Metadata } from "next";
import { Header } from "@/components/header/header";
import { ThemeProvider, useTheme } from "@/contexts/ThemeContext";
import "@/assets/styles/styles.scss";
import ClientLayout from "@/components/clientLayout/ClientLayout";
import { Toaster } from "react-hot-toast";
import { Analytics } from "@vercel/analytics/react";
import { Mulish } from "next/font/google";
import Script from "next/script";
import ClientSessionProvider from "@/components/clientSessionProvider/ClientSessionProvider";

const font = Mulish({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NotLazy",
  description: "Лень — главный автор этого блога",
  authors: [{ name: "NotLazy", url: "https://notlazy.org" }],
  openGraph: {
    title: "NotLazy",
    description: "Лень — главный автор этого блога",
    url: "https://notlazy.org",
    siteName: "NotLazy",
    images: [
      {
        url: "https://notlazy.org/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "NotLazy",
      },
    ],
    locale: "ru_RU",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NotLazy",
    description: "Лень — главный автор этого блога",
    images: ["https://notlazy.org/og-image.jpg"],
  },
  robots: "index, follow",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <head>
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-MJC16ETF2H"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || []; function gtag()
            {dataLayer.push(arguments)}
            gtag('js', new Date()); gtag('config', 'G-MJC16ETF2H');
          `}
        </Script>
      </head>

      <body className={font.className}>
        <ClientSessionProvider>
          <ThemeProvider>
            <Header />
            <ClientLayout>{children}</ClientLayout>
          </ThemeProvider>
        </ClientSessionProvider>

        <Toaster position="top-right" />
        <Analytics />
      </body>
    </html>
  );
}
