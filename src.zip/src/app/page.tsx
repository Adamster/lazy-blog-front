"use client";

import ErrorMessage from "@/components/errorMessages/ErrorMessage";
import Loading from "@/components/loading";
import PostPreview from "@/components/post/PostPreview";
import { IPost, IPosts } from "@/types";
import { API_URL, fetcher } from "@/utils/fetcher";
import useSWR from "swr";

export default function Home() {
  const { data, error, isLoading, mutate } = useSWR<IPosts>(
    `${API_URL}/posts`,
    fetcher
  );

  if (error || data?.code) return <ErrorMessage code={data?.code || ""} />;

  return (
    <div className="wrapper p-8">
      {isLoading && <Loading />}

      <div className="postsGrid">
        {data?.map((post: IPost) => (
          <PostPreview
            key={post.id}
            post={post}
            author={post.author}
            mutate={mutate}
          />
        ))}
      </div>
    </div>
  );
}
