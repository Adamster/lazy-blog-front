"use client";

import { useTheme } from "@/contexts/ThemeContext";
import { useSession, signOut } from "next-auth/react";
import { useEffect } from "react";

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { data: auth } = useSession();
  const { darkTheme } = useTheme();

  useEffect(() => {
    if (auth?.error === "RefreshAccessTokenError") {
      signOut();
    }
  }, [auth]);

  return (
    <main
      className="layout-main"
      data-color-mode={darkTheme ? "dark" : "light"}
    >
      {children}
    </main>
  );
}
