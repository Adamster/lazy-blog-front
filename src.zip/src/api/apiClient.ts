import { Configuration } from "./apis/runtime";
import {
  UsersApi,
  PostsApi,
  CommentsApi,
  TagsApi,
  MediaApi,
} from "./apis/apis";

const apiConfig = new Configuration({
  basePath:
    process.env.NEXT_PUBLIC_API_URL ||
    "https://lazy-blog-app.azurewebsites.net",
  fetchApi: fetch,
});

export const apiClient = {
  users: new UsersApi(apiConfig),
  posts: new PostsApi(apiConfig),
  comments: new CommentsApi(apiConfig),
  tags: new TagsApi(apiConfig),
  media: new MediaApi(apiConfig),
};
